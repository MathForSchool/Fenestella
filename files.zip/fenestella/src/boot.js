const bootSteps = [
  { msg: "Setting up...", duration: 900 },
  { msg: "Adding files...", duration: 800 },
  { msg: "Configuring user environment...", duration: 900 },
  { msg: "Loading resources...", duration: 850 },
  { msg: "Finalizing...", duration: 700 },
];

export function showBootMenu(onBooted) {
  const bootDiv = document.getElementById('boot');
  bootDiv.innerHTML = `
    <img src="../assets/boot-logo.jpg" class="boot-logo" alt="Boot Logo">
    <div class="boot-title">Fenestella Boot Menu</div>
    <button class="boot-btn" id="boot-btn">Boot</button>
  `;

  document.getElementById('boot-btn').onclick = () => {
    showLoading(bootDiv, onBooted);
  };
}

function showLoading(bootDiv, onBooted) {
  bootDiv.innerHTML = `
    <img src="../assets/boot-logo.jpg" class="boot-logo" alt="Boot Logo">
    <div class="boot-title">Fenestella Booting…</div>
    <div id="boot-status" class="boot-status"></div>
    <div class="boot-spinner"></div>
  `;
  let step = 0;
  const status = bootDiv.querySelector('#boot-status');

  function nextStep() {
    if (step < bootSteps.length) {
      status.textContent = bootSteps[step].msg;
      step++;
      setTimeout(nextStep, bootSteps[step - 1].duration);
    } else {
      status.textContent = "Boot successful";
      status.classList.add("boot-success");
      bootDiv.querySelector('.boot-spinner').style.display = 'none';
      setTimeout(() => {
        bootDiv.style.opacity = 0;
        setTimeout(() => {
          bootDiv.style.display = "none";
          onBooted();
        }, 700);
      }, 1100);
    }
  }
  nextStep();
}