let z = 20;
export function createWindow({ title, content, x = 100, y = 100, w = 340, h = 200 }) {
  const win = document.createElement('div');
  win.className = 'window';
  win.style.left = x + 'px';
  win.style.top = y + 'px';
  win.style.width = w + 'px';
  win.style.height = h + 'px';
  win.style.zIndex = z++;

  win.innerHTML = `
    <div class="window-header">
      <span>${title}</span>
      <button class="window-close">&times;</button>
    </div>
    <div class="window-content">${content}</div>
  `;

  document.getElementById('desktop').appendChild(win);

  // Dragging logic
  let isDragging = false, offsetX = 0, offsetY = 0;
  const header = win.querySelector('.window-header');
  header.onmousedown = (e) => {
    isDragging = true;
    offsetX = e.clientX - win.offsetLeft;
    offsetY = e.clientY - win.offsetTop;
    win.style.zIndex = z++;
    document.body.style.userSelect = 'none';
  };
  document.onmousemove = (e) => {
    if (isDragging) {
      win.style.left = Math.max(0, e.clientX - offsetX) + 'px';
      win.style.top = Math.max(0, e.clientY - offsetY) + 'px';
    }
  };
  document.onmouseup = () => {
    isDragging = false;
    document.body.style.userSelect = '';
  };

  // Close
  win.querySelector('.window-close').onclick = () => win.remove();
}

// Taskbar clock
export function updateClock() {
  const clock = document.getElementById('clock');
  if (clock) {
    const d = new Date();
    clock.textContent = d.toLocaleTimeString();
  }
}