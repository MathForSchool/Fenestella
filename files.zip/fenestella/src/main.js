import { showBootMenu } from './boot.js';
import { createDesktop } from './desktop.js';
import { updateClock } from './windowManager.js';

window.addEventListener('DOMContentLoaded', () => {
  showBootMenu(() => {
    document.getElementById('desktop').style.display = '';
    document.getElementById('taskbar').style.display = '';
    createDesktop();

    // Taskbar clock
    setInterval(updateClock, 1000);
    updateClock();
  });
});