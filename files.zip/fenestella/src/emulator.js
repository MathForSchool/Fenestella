import { createWindow } from './windowManager.js';

// Placeholder for emulator/virtualization integration
export function launchEmulator() {
  createWindow({
    title: 'Emulator',
    content: `
      <b>Emulator Placeholder</b><br>
      <i>Here, you can embed JS/WASM emulators, or connect to a remote VM.</i>
      <br><br>
      <code>src/emulator.js</code>
    `,
    x: 180, y: 180, w: 420, h: 260
  });
}