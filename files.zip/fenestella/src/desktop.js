import { createWindow } from './windowManager.js';
import { launchEmulator } from './emulator.js';

export function createDesktop() {
  const desktop = document.getElementById('desktop');
  const launcher = document.getElementById('launcher');

  // Example: Launch a welcome/info window at start
  createWindow({
    title: 'Welcome to Fenestella',
    content: `<b>This is a web desktop shell.</b><br>
      Use the launcher to open apps. <br>
      <i>Start hacking in <code>src/desktop.js</code>!</i>`,
    x: 120, y: 120
  });

  launcher.onclick = () => {
    createWindow({
      title: 'Fenestella Apps',
      content: `
        <button id="emulatorBtn">Open Emulator</button>
      `
    });
    setTimeout(() => {
      document.getElementById('emulatorBtn').onclick = () => {
        launchEmulator();
      };
    }, 100);
  };
}